/* =========================
   DATA
========================= */

const counties=[
"Baringo","Bomet","Bungoma","Busia",
"Elgeyo-Marakwet","Embu","Garissa",
"Homa Bay","Isiolo","Kajiado","Kakamega",
"Kericho","Kiambu","Kilifi","Kirinyaga",
"Kisii","Kisumu","Kitui","Kwale",
"Laikipia","Lamu","Machakos","Makueni",
"Mandera","Marsabit","Meru","Migori",
"Mombasa","Murang'a","Nairobi","Nakuru",
"Nandi","Narok","Nyamira","Nyandarua",
"Nyeri","Samburu","Siaya","Taita-Taveta",
"Tana River","Tharaka-Nithi","Trans Nzoia",
"Turkana","Uasin Gishu","Vihiga",
"Wajir","West Pokot"
];


const types=[
"Single Room",
"Bedsitter",
"1 Bedroom",
"2 Bedrooms",
"3 Bedrooms",
"4 Bedrooms",
"Airbnb"
];


const properties=[

{
id:1,
title:"Modern 1 Bedroom Apartment",
county:"Nairobi",
town:"Roysambu",
type:"1 Bedroom",
rent:18000,
verified:true,
img:"https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
meta:"1 bed • 1 bath • Parking",
phone:"254712345678"
},

{
id:2,
title:"Elegant Bedsitter near CBD",
county:"Nairobi",
town:"Kilimani",
type:"Bedsitter",
rent:14500,
verified:true,
img:"https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=900&q=80",
meta:"1 room • Security • Wi-Fi",
phone:"254723456789"
},

{
id:3,
title:"Spacious 2 Bedroom Home",
county:"Kisumu",
town:"Kisumu Central",
type:"2 Bedrooms",
rent:26000,
verified:false,
img:"https://images.unsplash.com/photo-1560185008-b033106af5c3?auto=format&fit=crop&w=900&q=80",
meta:"2 beds • 2 baths • Balcony",
phone:"254734567890"
},

{
id:4,
title:"Cozy Studio Apartment",
county:"Nakuru",
town:"Milimani",
type:"Bedsitter",
rent:12000,
verified:true,
img:"https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=900&q=80",
meta:"Studio • Water • Parking",
phone:"254745678901"
},

{
id:5,
title:"Family 3 Bedroom House",
county:"Uasin Gishu",
town:"Eldoret",
type:"3 Bedrooms",
rent:35000,
verified:true,
img:"https://images.unsplash.com/photo-1605146769289-440113cc3d00?auto=format&fit=crop&w=900&q=80",
meta:"3 beds • 2 baths • Compound",
phone:"254756789012"
},

{
id:6,
title:"Affordable Single Room",
county:"Nairobi",
town:"Kasarani",
type:"Single Room",
rent:6500,
verified:false,
img:"https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
meta:"Single room • Water • Security",
phone:"254767890123"
},

{
id:7,
title:"Spacious 4 Bedroom Family House",
county:"Kajiado",
town:"Ongata Rongai",
type:"4 Bedrooms",
rent:55000,
verified:true,
img:"https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=900&q=80",
meta:"4 beds • 3 baths • Parking • Compound",
phone:"254778901234"
},

{
id:8,
title:"Luxury 4 Bedroom Villa",
county:"Nairobi",
town:"Karen",
type:"4 Bedrooms",
rent:95000,
verified:true,
img:"https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=900&q=80",
meta:"4 beds • 4 baths • Garden • Parking",
phone:"254789012345"
}

];


let favorites=
JSON.parse(
localStorage.getItem("rentikaFavorites") || "[]"
);


/* =========================
   INITIALIZATION
========================= */

function populate(){

const countyHTML=
'<option value="">All counties</option>'+
counties.map(
c=>`<option>${c}</option>`
).join("");

document.getElementById("countySelect").innerHTML=
countyHTML;

document.getElementById("listCounty").innerHTML=
'<option value="">Select county</option>'+
counties.map(
c=>`<option>${c}</option>`
).join("");

document.getElementById("typeSelect").innerHTML=
'<option value="">All property types</option>'+
types.map(
t=>`<option>${t}</option>`
).join("");

document.getElementById("listType").innerHTML=
'<option value="">Select property type</option>'+
types.map(
t=>`<option>${t}</option>`
).join("");


const icons=[
"🚪","🛏️","🏠","🏡","🏘️","🏰","🌴"
];

document.getElementById("categories").innerHTML=
types.map(
(t,i)=>
`<button class="cat"
onclick="quickType('${t}')">
<div class="cat-icon">${icons[i]}</div>
${t}
</button>`
).join("");

renderProperties(properties);

updateUserInterface();

}


/* =========================
   PROPERTY DISPLAY
========================= */

function renderProperties(list){

const grid=
document.getElementById("propertyGrid");

document.getElementById("resultCount")
.textContent=
`${list.length} listing${list.length!==1?"s":""} found`;

if(!list.length){

grid.innerHTML=
'<div class="empty">No homes found. Try another search.</div>';

return;
}


grid.innerHTML=

list.map(p=>`

<article class="card">

<div
class="card-img"
style="background-image:url('${p.img}')">

${p.verified?
'<span class="verified">✓ Verified</span>'
:""}

<button
class="favorite"
onclick="toggleFavorite(${p.id})">

${favorites.includes(p.id)?"♥":"♡"}

</button>

</div>


<div class="card-body">

<h3>
${p.title}
</h3>

<div class="location">
📍 ${p.town}, ${p.county}
</div>

<div class="price">
KSh ${p.rent.toLocaleString()}
<small>/ month</small>
</div>

<div class="meta">
${p.meta}
</div>


<div class="card-actions">

<button
class="details"
onclick="showProperty(${p.id})">
Details
</button>

<button
class="chat"
onclick="openMessages()">
Chat
</button>

<button
class="wa"
onclick="whatsapp('${p.phone}','${p.title.replace(/'/g,"")}')">
WhatsApp
</button>

</div>

</div>

</article>

`).join("");

}


/* =========================
   SEARCH
========================= */

function searchHomes(){

const q=
document.getElementById("searchInput")
.value.toLowerCase();

const c=
document.getElementById("countySelect")
.value;

const t=
document.getElementById("typeSelect")
.value;


const list=
properties.filter(p=>

(!q ||
(
p.title+" "+
p.town+" "+
p.county+" "+
p.type
)
.toLowerCase()
.includes(q))

&&

(!c || p.county===c)

&&

(!t || p.type===t)

);


renderProperties(list);

document.getElementById("homes")
.scrollIntoView({
behavior:"smooth"
});

}


function quickCounty(c){

document.getElementById("countySelect")
.value=c;

searchHomes();

}


function quickType(t){

document.getElementById("typeSelect")
.value=t;

searchHomes();

}


/* =========================
   FAVORITES
========================= */

function toggleFavorite(id){

favorites=
favorites.includes(id)

?favorites.filter(x=>x!==id)

:[...favorites,id];

localStorage.setItem(
"rentikaFavorites",
JSON.stringify(favorites)
);

renderProperties(properties);

}


/* =========================
   PROPERTY DETAILS
========================= */

function showProperty(id){

const p=
properties.find(x=>x.id===id);

document.getElementById("propertyDetails")
.innerHTML=`

<img
src="${p.img}"
style="
width:100%;
height:260px;
object-fit:cover;
border-radius:13px;
">

<div style="margin-top:18px">

<div class="eyebrow">
${p.verified
?"✓ VERIFIED LISTING"
:"RENTIKA LISTING"}
</div>

<h2>
${p.title}
</h2>

<p class="location">
📍 ${p.town}, ${p.county}
</p>

<div class="price">
KSh ${p.rent.toLocaleString()} / month
</div>

<p style="margin:15px 0;color:#596761">
${p.meta}
</p>

<p>
This property is available for rent.
Contact the landlord through Rentika or
WhatsApp to arrange a viewing.
</p>

<div
style="
display:flex;
gap:8px;
margin-top:18px;
flex-wrap:wrap;
">

<button
class="btn btn-green"
onclick="openMessages()">
💬 Rentika Chat
</button>

<button
class="btn btn-whatsapp"
onclick="whatsapp('${p.phone}','${p.title.replace(/'/g,"")}')">
☘ WhatsApp Landlord
</button>

</div>

</div>
`;

openModal("propertyModal");

}


/* =========================
   WHATSAPP
========================= */

function whatsapp(phone,title){

const message=
"Hello, I found your "+
title+
" listing on Rentika. Is it still available?";

window.open(
"https://wa.me/"+
phone+
"?text="+
encodeURIComponent(message),
"_blank"
);

}


/* =========================
   MESSAGES
========================= */

function openMessages(){

closeModal("propertyModal");

openModal("messagesModal");

}


function sendMessage(){

const input=
document.getElementById("messageInput");

if(!input.value.trim())
return;

const message=
document.createElement("div");

message.className="msg me";

message.textContent=
input.value;

input.parentElement
.parentElement
.insertBefore(
message,
input.parentElement
);

input.value="";

}


/* =========================
   AUTHENTICATION
========================= */

function getUsers(){

return JSON.parse(
localStorage.getItem("rentikaUsers")
||"[]"
);

}


function signup(e){

e.preventDefault();

const name=
document.getElementById("signupName")
.value.trim();

const code=
document.getElementById("signupCode")
.value;

const phone=
code+
document.getElementById("signupPhone")
.value.trim();

const password=
document.getElementById("signupPassword")
.value;

const confirm=
document.getElementById("signupConfirm")
.value;


if(password!==confirm){

alert("Passwords do not match.");

return;

}


if(password.length<6){

alert("Password must contain at least 6 characters.");

return;

}


const users=getUsers();


if(
users.some(
u=>u.phone===phone
)
){

alert(
"An account with this phone number already exists."
);

return;

}


users.push({
name:name,
phone:phone,
password:password
});


localStorage.setItem(
"rentikaUsers",
JSON.stringify(users)
);

localStorage.setItem(
"rentikaCurrentUser",
phone
);


alert(
"Account created successfully. Welcome to Rentika!"
);

e.target.reset();

closeModal("signupModal");

updateUserInterface();

}


function login(e){

e.preventDefault();

const code=
document.getElementById("loginCode")
.value;

const phone=
code+
document.getElementById("loginPhone")
.value.trim();

const password=
document.getElementById("loginPassword")
.value;


const user=
getUsers().find(
u=>
u.phone===phone &&
u.password===password
);


if(!user){

alert(
"Incorrect phone number or password."
);

return;

}


localStorage.setItem(
"rentikaCurrentUser",
phone
);

alert(
"Welcome back, "+user.name+"!"
);

e.target.reset();

closeModal("loginModal");

updateUserInterface();

}


function logout(){

localStorage.removeItem(
"rentikaCurrentUser"
);

updateUserInterface();

}


function updateUserInterface(){

const current=
localStorage.getItem(
"rentikaCurrentUser"
);

const status=
document.getElementById("userStatus");

const signin=
document.getElementById("signinBtn");

const signup=
document.getElementById("signupBtn");


if(current){

const user=
getUsers().find(
u=>u.phone===current
);

if(user){

status.innerHTML=
`<span class="user-status">
Hi, ${user.name.split(" ")[0]}
</span>`;

signin.style.display="none";

signup.textContent="Sign Out";

signup.onclick=logout;

}

}else{

status.innerHTML="";

signin.style.display="";

signup.style.display="";

signup.textContent="Sign Up";

signup.onclick=
()=>openModal("signupModal");

}

}


/* =========================
   LISTING
========================= */

function submitListing(e){

e.preventDefault();

const title=
document.getElementById("listTitle")
.value;

const town=
document.getElementById("listTown")
.value;

const county=
document.getElementById("listCounty")
.value;

const type=
document.getElementById("listType")
.value;

const rent=
document.getElementById("listRent")
.value;


alert(
"Your "+type+
" property in "+town+
", "+county+
" has been saved in this demo."
);

e.target.reset();

closeModal("listModal");

}


/* =========================
   MODALS
========================= */

function openModal(id){

document
.getElementById(id)
.classList
.add("show");

}


function closeModal(id){

document
.getElementById(id)
.classList
.remove("show");

}


function switchAuth(from,to){

closeModal(from);

openModal(to);

}


function toggleMenu(){

const nav=
document.querySelector(".navlinks");

nav.style.display=
nav.style.display==="flex"
?"none"
:"flex";

}


window.onclick=function(e){

if(
e.target.classList
.contains("modal")
){

e.target.classList
.remove("show");

}

};


populate();
