Rentika source code files
=========================

index.html  - HTML structure and content, linked to the separate CSS and JavaScript files.
styles.css  - CSS styles extracted from the original HTML.
script.js   - JavaScript extracted from the original HTML.
rentika_full_source.html - Full original page source with CSS and JavaScript embedded.

To view the separated version, keep index.html, styles.css, and script.js in the same folder,
then open index.html in a browser. Some features that depend on external services or APIs
may require internet access or additional configuration.
